﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.tmrmobilcepat = New System.Windows.Forms.Timer(Me.components)
        Me.tmrmobilbiasa = New System.Windows.Forms.Timer(Me.components)
        Me.tmrmobillama = New System.Windows.Forms.Timer(Me.components)
        Me.tmrpolisi = New System.Windows.Forms.Timer(Me.components)
        Me.tmrMOBILAPT = New System.Windows.Forms.Timer(Me.components)
        Me.tmrPALANG = New System.Windows.Forms.Timer(Me.components)
        Me.TmrCHECKDB = New System.Windows.Forms.Timer(Me.components)
        Me.tmrMOBILAPT2 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrPALANG2 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrETOLL = New System.Windows.Forms.Timer(Me.components)
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtSTATUS = New System.Windows.Forms.TextBox()
        Me.lblgate = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnHIDE = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.labelgate = New System.Windows.Forms.Label()
        Me.lblETOLL = New System.Windows.Forms.Label()
        Me.tmrWKTETOLL = New System.Windows.Forms.Timer(Me.components)
        Me.Button3 = New System.Windows.Forms.Button()
        Me.tmrPALANGETOLL = New System.Windows.Forms.Timer(Me.components)
        Me.tmrPALANGETOLL2 = New System.Windows.Forms.Timer(Me.components)
        Me.Button5 = New System.Windows.Forms.Button()
        Me.grpMOBIL = New System.Windows.Forms.GroupBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.txtPENGEMUDI = New System.Windows.Forms.TextBox()
        Me.lbltopay = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.lblpulsa = New System.Windows.Forms.Label()
        Me.lblharga = New System.Windows.Forms.Label()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox67 = New System.Windows.Forms.PictureBox()
        Me.PictureBox66 = New System.Windows.Forms.PictureBox()
        Me.pctLAMPUETOLL = New System.Windows.Forms.PictureBox()
        Me.PictureBox65 = New System.Windows.Forms.PictureBox()
        Me.PictureBox61 = New System.Windows.Forms.PictureBox()
        Me.PictureBox121 = New System.Windows.Forms.PictureBox()
        Me.PictureBox58 = New System.Windows.Forms.PictureBox()
        Me.PictureBox56 = New System.Windows.Forms.PictureBox()
        Me.PictureBox89 = New System.Windows.Forms.PictureBox()
        Me.PictureBox64 = New System.Windows.Forms.PictureBox()
        Me.pctLORONG2 = New System.Windows.Forms.PictureBox()
        Me.pctLORONG1 = New System.Windows.Forms.PictureBox()
        Me.palang = New System.Windows.Forms.PictureBox()
        Me.PictureBox84 = New System.Windows.Forms.PictureBox()
        Me.LAMPUAPT = New System.Windows.Forms.PictureBox()
        Me.PictureBox63 = New System.Windows.Forms.PictureBox()
        Me.PictureBox151 = New System.Windows.Forms.PictureBox()
        Me.PictureBox59 = New System.Windows.Forms.PictureBox()
        Me.PictureBox116 = New System.Windows.Forms.PictureBox()
        Me.PictureBox62 = New System.Windows.Forms.PictureBox()
        Me.pctPALANGETOLL = New System.Windows.Forms.PictureBox()
        Me.PictureBox117 = New System.Windows.Forms.PictureBox()
        Me.PictureBox55 = New System.Windows.Forms.PictureBox()
        Me.PictureBox60 = New System.Windows.Forms.PictureBox()
        Me.pctETOLL = New System.Windows.Forms.PictureBox()
        Me.PictureBox150 = New System.Windows.Forms.PictureBox()
        Me.PictureBox148 = New System.Windows.Forms.PictureBox()
        Me.PictureBox68 = New System.Windows.Forms.PictureBox()
        Me.PictureBox70 = New System.Windows.Forms.PictureBox()
        Me.PictureBox87 = New System.Windows.Forms.PictureBox()
        Me.PictureBox139 = New System.Windows.Forms.PictureBox()
        Me.PictureBox140 = New System.Windows.Forms.PictureBox()
        Me.PictureBox141 = New System.Windows.Forms.PictureBox()
        Me.pctMOBILAPT = New System.Windows.Forms.PictureBox()
        Me.PictureBox138 = New System.Windows.Forms.PictureBox()
        Me.PictureBox137 = New System.Windows.Forms.PictureBox()
        Me.PictureBox135 = New System.Windows.Forms.PictureBox()
        Me.PictureBox136 = New System.Windows.Forms.PictureBox()
        Me.PictureBox134 = New System.Windows.Forms.PictureBox()
        Me.PictureBox133 = New System.Windows.Forms.PictureBox()
        Me.PictureBox132 = New System.Windows.Forms.PictureBox()
        Me.PictureBox131 = New System.Windows.Forms.PictureBox()
        Me.PictureBox130 = New System.Windows.Forms.PictureBox()
        Me.PictureBox129 = New System.Windows.Forms.PictureBox()
        Me.PictureBox128 = New System.Windows.Forms.PictureBox()
        Me.PictureBox127 = New System.Windows.Forms.PictureBox()
        Me.PictureBox125 = New System.Windows.Forms.PictureBox()
        Me.PictureBox124 = New System.Windows.Forms.PictureBox()
        Me.PictureBox123 = New System.Windows.Forms.PictureBox()
        Me.PictureBox120 = New System.Windows.Forms.PictureBox()
        Me.PictureBox119 = New System.Windows.Forms.PictureBox()
        Me.PictureBox118 = New System.Windows.Forms.PictureBox()
        Me.PictureBox90 = New System.Windows.Forms.PictureBox()
        Me.PictureBox91 = New System.Windows.Forms.PictureBox()
        Me.PictureBox92 = New System.Windows.Forms.PictureBox()
        Me.PictureBox93 = New System.Windows.Forms.PictureBox()
        Me.PictureBox94 = New System.Windows.Forms.PictureBox()
        Me.PictureBox95 = New System.Windows.Forms.PictureBox()
        Me.PictureBox96 = New System.Windows.Forms.PictureBox()
        Me.PictureBox97 = New System.Windows.Forms.PictureBox()
        Me.PictureBox98 = New System.Windows.Forms.PictureBox()
        Me.PictureBox99 = New System.Windows.Forms.PictureBox()
        Me.PictureBox100 = New System.Windows.Forms.PictureBox()
        Me.PictureBox101 = New System.Windows.Forms.PictureBox()
        Me.PictureBox102 = New System.Windows.Forms.PictureBox()
        Me.PictureBox103 = New System.Windows.Forms.PictureBox()
        Me.PictureBox104 = New System.Windows.Forms.PictureBox()
        Me.PictureBox105 = New System.Windows.Forms.PictureBox()
        Me.PictureBox106 = New System.Windows.Forms.PictureBox()
        Me.PictureBox107 = New System.Windows.Forms.PictureBox()
        Me.PictureBox108 = New System.Windows.Forms.PictureBox()
        Me.PictureBox109 = New System.Windows.Forms.PictureBox()
        Me.PictureBox110 = New System.Windows.Forms.PictureBox()
        Me.PictureBox111 = New System.Windows.Forms.PictureBox()
        Me.PictureBox112 = New System.Windows.Forms.PictureBox()
        Me.PictureBox113 = New System.Windows.Forms.PictureBox()
        Me.PictureBox114 = New System.Windows.Forms.PictureBox()
        Me.PictureBox115 = New System.Windows.Forms.PictureBox()
        Me.PictureBox88 = New System.Windows.Forms.PictureBox()
        Me.PictureBox86 = New System.Windows.Forms.PictureBox()
        Me.PictureBox85 = New System.Windows.Forms.PictureBox()
        Me.PictureBox79 = New System.Windows.Forms.PictureBox()
        Me.PictureBox57 = New System.Windows.Forms.PictureBox()
        Me.PictureBox77 = New System.Windows.Forms.PictureBox()
        Me.PictureBox76 = New System.Windows.Forms.PictureBox()
        Me.PictureBox74 = New System.Windows.Forms.PictureBox()
        Me.PictureBox73 = New System.Windows.Forms.PictureBox()
        Me.PictureBox72 = New System.Windows.Forms.PictureBox()
        Me.PictureBox71 = New System.Windows.Forms.PictureBox()
        Me.PictureBox69 = New System.Windows.Forms.PictureBox()
        Me.pctMLAMA = New System.Windows.Forms.PictureBox()
        Me.pctMBIASA = New System.Windows.Forms.PictureBox()
        Me.pctSPORT = New System.Windows.Forms.PictureBox()
        Me.pctMOBILPOL = New System.Windows.Forms.PictureBox()
        Me.PictureBox75 = New System.Windows.Forms.PictureBox()
        Me.PictureBox54 = New System.Windows.Forms.PictureBox()
        Me.PictureBox53 = New System.Windows.Forms.PictureBox()
        Me.PictureBox52 = New System.Windows.Forms.PictureBox()
        Me.PictureBox51 = New System.Windows.Forms.PictureBox()
        Me.PictureBox50 = New System.Windows.Forms.PictureBox()
        Me.PictureBox49 = New System.Windows.Forms.PictureBox()
        Me.PictureBox48 = New System.Windows.Forms.PictureBox()
        Me.PictureBox47 = New System.Windows.Forms.PictureBox()
        Me.PictureBox46 = New System.Windows.Forms.PictureBox()
        Me.PictureBox45 = New System.Windows.Forms.PictureBox()
        Me.PictureBox44 = New System.Windows.Forms.PictureBox()
        Me.PictureBox43 = New System.Windows.Forms.PictureBox()
        Me.PictureBox42 = New System.Windows.Forms.PictureBox()
        Me.PictureBox41 = New System.Windows.Forms.PictureBox()
        Me.PictureBox40 = New System.Windows.Forms.PictureBox()
        Me.PictureBox39 = New System.Windows.Forms.PictureBox()
        Me.PictureBox38 = New System.Windows.Forms.PictureBox()
        Me.PictureBox37 = New System.Windows.Forms.PictureBox()
        Me.PictureBox36 = New System.Windows.Forms.PictureBox()
        Me.PictureBox35 = New System.Windows.Forms.PictureBox()
        Me.PictureBox34 = New System.Windows.Forms.PictureBox()
        Me.PictureBox33 = New System.Windows.Forms.PictureBox()
        Me.PictureBox32 = New System.Windows.Forms.PictureBox()
        Me.PictureBox31 = New System.Windows.Forms.PictureBox()
        Me.PictureBox30 = New System.Windows.Forms.PictureBox()
        Me.PictureBox29 = New System.Windows.Forms.PictureBox()
        Me.PictureBox28 = New System.Windows.Forms.PictureBox()
        Me.PictureBox27 = New System.Windows.Forms.PictureBox()
        Me.PictureBox26 = New System.Windows.Forms.PictureBox()
        Me.PictureBox25 = New System.Windows.Forms.PictureBox()
        Me.PictureBox24 = New System.Windows.Forms.PictureBox()
        Me.PictureBox23 = New System.Windows.Forms.PictureBox()
        Me.PictureBox22 = New System.Windows.Forms.PictureBox()
        Me.PictureBox21 = New System.Windows.Forms.PictureBox()
        Me.PictureBox20 = New System.Windows.Forms.PictureBox()
        Me.PictureBox19 = New System.Windows.Forms.PictureBox()
        Me.PictureBox18 = New System.Windows.Forms.PictureBox()
        Me.PictureBox17 = New System.Windows.Forms.PictureBox()
        Me.PictureBox16 = New System.Windows.Forms.PictureBox()
        Me.PictureBox15 = New System.Windows.Forms.PictureBox()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.tmrETOLL2 = New System.Windows.Forms.Timer(Me.components)
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.grpMOBIL.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox67, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox66, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctLAMPUETOLL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox65, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox61, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox121, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox58, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox56, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox89, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox64, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctLORONG2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctLORONG1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.palang, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox84, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LAMPUAPT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox63, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox151, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox59, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox116, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox62, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctPALANGETOLL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox117, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox55, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox60, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctETOLL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox150, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox148, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox68, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox70, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox87, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox139, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox140, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox141, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctMOBILAPT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox138, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox137, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox135, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox136, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox134, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox133, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox132, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox131, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox130, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox129, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox128, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox127, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox125, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox124, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox123, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox120, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox119, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox118, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox90, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox91, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox92, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox93, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox94, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox95, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox96, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox97, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox98, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox99, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox100, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox101, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox102, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox103, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox104, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox105, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox106, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox107, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox108, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox109, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox110, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox111, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox112, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox113, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox114, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox115, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox88, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox86, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox85, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox79, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox57, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox77, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox76, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox74, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox73, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox72, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox71, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox69, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctMLAMA, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctMBIASA, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctSPORT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pctMOBILPOL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox75, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox54, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox53, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox52, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox51, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox50, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox49, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox48, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox47, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox46, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox45, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox44, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox43, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox42, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox41, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox40, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox39, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox38, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox37, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox36, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox35, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox30, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tmrmobilcepat
        '
        Me.tmrmobilcepat.Enabled = True
        Me.tmrmobilcepat.Interval = 10
        '
        'tmrmobilbiasa
        '
        Me.tmrmobilbiasa.Enabled = True
        Me.tmrmobilbiasa.Interval = 10
        '
        'tmrmobillama
        '
        Me.tmrmobillama.Enabled = True
        Me.tmrmobillama.Interval = 10
        '
        'tmrpolisi
        '
        Me.tmrpolisi.Enabled = True
        Me.tmrpolisi.Interval = 10
        '
        'tmrMOBILAPT
        '
        Me.tmrMOBILAPT.Interval = 10
        '
        'tmrPALANG
        '
        Me.tmrPALANG.Interval = 10
        '
        'TmrCHECKDB
        '
        Me.TmrCHECKDB.Interval = 500
        '
        'tmrMOBILAPT2
        '
        Me.tmrMOBILAPT2.Interval = 10
        '
        'tmrPALANG2
        '
        Me.tmrPALANG2.Interval = 10
        '
        'tmrETOLL
        '
        Me.tmrETOLL.Interval = 10
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Gray
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Location = New System.Drawing.Point(685, 282)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(86, 23)
        Me.Button1.TabIndex = 289
        Me.Button1.Text = "Repeat"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'txtSTATUS
        '
        Me.txtSTATUS.BackColor = System.Drawing.SystemColors.HotTrack
        Me.txtSTATUS.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSTATUS.ForeColor = System.Drawing.Color.Yellow
        Me.txtSTATUS.Location = New System.Drawing.Point(827, 281)
        Me.txtSTATUS.Multiline = True
        Me.txtSTATUS.Name = "txtSTATUS"
        Me.txtSTATUS.Size = New System.Drawing.Size(66, 25)
        Me.txtSTATUS.TabIndex = 295
        Me.txtSTATUS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblgate
        '
        Me.lblgate.BackColor = System.Drawing.Color.White
        Me.lblgate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblgate.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblgate.Location = New System.Drawing.Point(623, 250)
        Me.lblgate.Name = "lblgate"
        Me.lblgate.Size = New System.Drawing.Size(56, 19)
        Me.lblgate.TabIndex = 298
        Me.lblgate.Text = "cibubur"
        Me.lblgate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(492, 262)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 31)
        Me.Label1.TabIndex = 306
        Me.Label1.Text = "Gate Tol" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Gate A"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.White
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(559, 292)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(10, 39)
        Me.Label4.TabIndex = 340
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnHIDE
        '
        Me.btnHIDE.Location = New System.Drawing.Point(570, 342)
        Me.btnHIDE.Name = "btnHIDE"
        Me.btnHIDE.Size = New System.Drawing.Size(33, 23)
        Me.btnHIDE.TabIndex = 343
        Me.btnHIDE.Text = "H"
        Me.btnHIDE.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.White
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(612, 186)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 19)
        Me.Label2.TabIndex = 346
        Me.Label2.Text = "Gate A"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.White
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(531, 203)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(75, 31)
        Me.Label3.TabIndex = 348
        Me.Label3.Text = "Gate Tol" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Gate A"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'labelgate
        '
        Me.labelgate.BackColor = System.Drawing.Color.White
        Me.labelgate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labelgate.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labelgate.Location = New System.Drawing.Point(623, 253)
        Me.labelgate.Name = "labelgate"
        Me.labelgate.Size = New System.Drawing.Size(56, 19)
        Me.labelgate.TabIndex = 349
        Me.labelgate.Text = "Gate A"
        Me.labelgate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblETOLL
        '
        Me.lblETOLL.AutoSize = True
        Me.lblETOLL.BackColor = System.Drawing.Color.Silver
        Me.lblETOLL.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblETOLL.ForeColor = System.Drawing.Color.Blue
        Me.lblETOLL.Location = New System.Drawing.Point(752, 221)
        Me.lblETOLL.Name = "lblETOLL"
        Me.lblETOLL.Size = New System.Drawing.Size(14, 13)
        Me.lblETOLL.TabIndex = 351
        Me.lblETOLL.Text = "0"
        '
        'tmrWKTETOLL
        '
        Me.tmrWKTETOLL.Interval = 1000
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Silver
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(12, 299)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(73, 23)
        Me.Button3.TabIndex = 353
        Me.Button3.Text = "Compare"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'tmrPALANGETOLL
        '
        Me.tmrPALANGETOLL.Interval = 10
        '
        'tmrPALANGETOLL2
        '
        Me.tmrPALANGETOLL2.Interval = 10
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.Silver
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Location = New System.Drawing.Point(91, 299)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(73, 23)
        Me.Button5.TabIndex = 360
        Me.Button5.Text = "Start"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'grpMOBIL
        '
        Me.grpMOBIL.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.dalem
        Me.grpMOBIL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.grpMOBIL.Controls.Add(Me.Label6)
        Me.grpMOBIL.Controls.Add(Me.Label5)
        Me.grpMOBIL.Controls.Add(Me.Button6)
        Me.grpMOBIL.Controls.Add(Me.txtPENGEMUDI)
        Me.grpMOBIL.Controls.Add(Me.lbltopay)
        Me.grpMOBIL.Controls.Add(Me.Button4)
        Me.grpMOBIL.Controls.Add(Me.lblpulsa)
        Me.grpMOBIL.Controls.Add(Me.lblharga)
        Me.grpMOBIL.Location = New System.Drawing.Point(4, 3)
        Me.grpMOBIL.Name = "grpMOBIL"
        Me.grpMOBIL.Size = New System.Drawing.Size(307, 275)
        Me.grpMOBIL.TabIndex = 361
        Me.grpMOBIL.TabStop = False
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(262, 245)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(45, 23)
        Me.Button6.TabIndex = 360
        Me.Button6.Text = "Hide"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'txtPENGEMUDI
        '
        Me.txtPENGEMUDI.Location = New System.Drawing.Point(164, 138)
        Me.txtPENGEMUDI.Name = "txtPENGEMUDI"
        Me.txtPENGEMUDI.Size = New System.Drawing.Size(100, 20)
        Me.txtPENGEMUDI.TabIndex = 355
        '
        'lbltopay
        '
        Me.lbltopay.AutoSize = True
        Me.lbltopay.BackColor = System.Drawing.Color.Transparent
        Me.lbltopay.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltopay.ForeColor = System.Drawing.Color.Black
        Me.lbltopay.Location = New System.Drawing.Point(170, 79)
        Me.lbltopay.Name = "lbltopay"
        Me.lbltopay.Size = New System.Drawing.Size(14, 13)
        Me.lbltopay.TabIndex = 356
        Me.lbltopay.Text = "0"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(268, 136)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(33, 23)
        Me.Button4.TabIndex = 359
        Me.Button4.Text = "Set"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'lblpulsa
        '
        Me.lblpulsa.AutoSize = True
        Me.lblpulsa.BackColor = System.Drawing.Color.Transparent
        Me.lblpulsa.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpulsa.ForeColor = System.Drawing.Color.Black
        Me.lblpulsa.Location = New System.Drawing.Point(170, 94)
        Me.lblpulsa.Name = "lblpulsa"
        Me.lblpulsa.Size = New System.Drawing.Size(14, 13)
        Me.lblpulsa.TabIndex = 357
        Me.lblpulsa.Text = "0"
        '
        'lblharga
        '
        Me.lblharga.AutoSize = True
        Me.lblharga.BackColor = System.Drawing.Color.Transparent
        Me.lblharga.ForeColor = System.Drawing.Color.Black
        Me.lblharga.Location = New System.Drawing.Point(171, 189)
        Me.lblharga.Name = "lblharga"
        Me.lblharga.Size = New System.Drawing.Size(13, 13)
        Me.lblharga.TabIndex = 358
        Me.lblharga.Text = "0"
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.Gray
        Me.PictureBox6.Location = New System.Drawing.Point(-4, 372)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(1384, 12)
        Me.PictureBox6.TabIndex = 142
        Me.PictureBox6.TabStop = False
        '
        'PictureBox67
        '
        Me.PictureBox67.BackColor = System.Drawing.Color.Silver
        Me.PictureBox67.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.icon_31883_960_720
        Me.PictureBox67.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox67.Location = New System.Drawing.Point(332, 230)
        Me.PictureBox67.Name = "PictureBox67"
        Me.PictureBox67.Size = New System.Drawing.Size(11, 14)
        Me.PictureBox67.TabIndex = 354
        Me.PictureBox67.TabStop = False
        '
        'PictureBox66
        '
        Me.PictureBox66.BackColor = System.Drawing.Color.Gold
        Me.PictureBox66.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.pembatasgatetol
        Me.PictureBox66.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox66.Location = New System.Drawing.Point(851, 305)
        Me.PictureBox66.Name = "PictureBox66"
        Me.PictureBox66.Size = New System.Drawing.Size(65, 13)
        Me.PictureBox66.TabIndex = 352
        Me.PictureBox66.TabStop = False
        '
        'pctLAMPUETOLL
        '
        Me.pctLAMPUETOLL.BackColor = System.Drawing.Color.Red
        Me.pctLAMPUETOLL.Location = New System.Drawing.Point(707, 215)
        Me.pctLAMPUETOLL.Name = "pctLAMPUETOLL"
        Me.pctLAMPUETOLL.Size = New System.Drawing.Size(13, 13)
        Me.pctLAMPUETOLL.TabIndex = 213
        Me.pctLAMPUETOLL.TabStop = False
        '
        'PictureBox65
        '
        Me.PictureBox65.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox65.Location = New System.Drawing.Point(700, 208)
        Me.PictureBox65.Name = "PictureBox65"
        Me.PictureBox65.Size = New System.Drawing.Size(25, 33)
        Me.PictureBox65.TabIndex = 211
        Me.PictureBox65.TabStop = False
        '
        'PictureBox61
        '
        Me.PictureBox61.BackColor = System.Drawing.Color.Gold
        Me.PictureBox61.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.pembatasgatetol
        Me.PictureBox61.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox61.Location = New System.Drawing.Point(661, 240)
        Me.PictureBox61.Name = "PictureBox61"
        Me.PictureBox61.Size = New System.Drawing.Size(55, 10)
        Me.PictureBox61.TabIndex = 283
        Me.PictureBox61.TabStop = False
        '
        'PictureBox121
        '
        Me.PictureBox121.BackColor = System.Drawing.Color.Gold
        Me.PictureBox121.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.pembatasgatetol
        Me.PictureBox121.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox121.Location = New System.Drawing.Point(609, 240)
        Me.PictureBox121.Name = "PictureBox121"
        Me.PictureBox121.Size = New System.Drawing.Size(55, 10)
        Me.PictureBox121.TabIndex = 282
        Me.PictureBox121.TabStop = False
        '
        'PictureBox58
        '
        Me.PictureBox58.BackColor = System.Drawing.Color.White
        Me.PictureBox58.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox58.Location = New System.Drawing.Point(-4, 202)
        Me.PictureBox58.Name = "PictureBox58"
        Me.PictureBox58.Size = New System.Drawing.Size(615, 11)
        Me.PictureBox58.TabIndex = 233
        Me.PictureBox58.TabStop = False
        '
        'PictureBox56
        '
        Me.PictureBox56.BackColor = System.Drawing.Color.Silver
        Me.PictureBox56.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.gerbang_out
        Me.PictureBox56.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox56.Location = New System.Drawing.Point(606, 190)
        Me.PictureBox56.Name = "PictureBox56"
        Me.PictureBox56.Size = New System.Drawing.Size(65, 51)
        Me.PictureBox56.TabIndex = 200
        Me.PictureBox56.TabStop = False
        '
        'PictureBox89
        '
        Me.PictureBox89.BackColor = System.Drawing.Color.White
        Me.PictureBox89.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox89.Location = New System.Drawing.Point(700, 203)
        Me.PictureBox89.Name = "PictureBox89"
        Me.PictureBox89.Size = New System.Drawing.Size(671, 10)
        Me.PictureBox89.TabIndex = 235
        Me.PictureBox89.TabStop = False
        '
        'PictureBox64
        '
        Me.PictureBox64.BackColor = System.Drawing.Color.Silver
        Me.PictureBox64.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.etoll
        Me.PictureBox64.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox64.Location = New System.Drawing.Point(660, 195)
        Me.PictureBox64.Name = "PictureBox64"
        Me.PictureBox64.Size = New System.Drawing.Size(48, 51)
        Me.PictureBox64.TabIndex = 344
        Me.PictureBox64.TabStop = False
        '
        'pctLORONG2
        '
        Me.pctLORONG2.BackColor = System.Drawing.Color.DimGray
        Me.pctLORONG2.Location = New System.Drawing.Point(610, 340)
        Me.pctLORONG2.Name = "pctLORONG2"
        Me.pctLORONG2.Size = New System.Drawing.Size(217, 35)
        Me.pctLORONG2.TabIndex = 342
        Me.pctLORONG2.TabStop = False
        '
        'pctLORONG1
        '
        Me.pctLORONG1.BackColor = System.Drawing.Color.Gray
        Me.pctLORONG1.Location = New System.Drawing.Point(610, 281)
        Me.pctLORONG1.Name = "pctLORONG1"
        Me.pctLORONG1.Size = New System.Drawing.Size(217, 59)
        Me.pctLORONG1.TabIndex = 341
        Me.pctLORONG1.TabStop = False
        '
        'palang
        '
        Me.palang.BackColor = System.Drawing.Color.Yellow
        Me.palang.Location = New System.Drawing.Point(811, 290)
        Me.palang.Name = "palang"
        Me.palang.Size = New System.Drawing.Size(10, 70)
        Me.palang.TabIndex = 214
        Me.palang.TabStop = False
        '
        'PictureBox84
        '
        Me.PictureBox84.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox84.Location = New System.Drawing.Point(804, 281)
        Me.PictureBox84.Name = "PictureBox84"
        Me.PictureBox84.Size = New System.Drawing.Size(23, 25)
        Me.PictureBox84.TabIndex = 229
        Me.PictureBox84.TabStop = False
        '
        'LAMPUAPT
        '
        Me.LAMPUAPT.BackColor = System.Drawing.Color.Red
        Me.LAMPUAPT.Location = New System.Drawing.Point(779, 281)
        Me.LAMPUAPT.Name = "LAMPUAPT"
        Me.LAMPUAPT.Size = New System.Drawing.Size(15, 15)
        Me.LAMPUAPT.TabIndex = 212
        Me.LAMPUAPT.TabStop = False
        '
        'PictureBox63
        '
        Me.PictureBox63.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox63.Location = New System.Drawing.Point(771, 273)
        Me.PictureBox63.Name = "PictureBox63"
        Me.PictureBox63.Size = New System.Drawing.Size(34, 32)
        Me.PictureBox63.TabIndex = 209
        Me.PictureBox63.TabStop = False
        '
        'PictureBox151
        '
        Me.PictureBox151.BackColor = System.Drawing.Color.Gray
        Me.PictureBox151.Location = New System.Drawing.Point(563, 281)
        Me.PictureBox151.Name = "PictureBox151"
        Me.PictureBox151.Size = New System.Drawing.Size(48, 59)
        Me.PictureBox151.TabIndex = 339
        Me.PictureBox151.TabStop = False
        '
        'PictureBox59
        '
        Me.PictureBox59.BackColor = System.Drawing.Color.Gold
        Me.PictureBox59.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.pembatasgatetol
        Me.PictureBox59.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox59.Location = New System.Drawing.Point(601, 305)
        Me.PictureBox59.Name = "PictureBox59"
        Me.PictureBox59.Size = New System.Drawing.Size(65, 13)
        Me.PictureBox59.TabIndex = 276
        Me.PictureBox59.TabStop = False
        '
        'PictureBox116
        '
        Me.PictureBox116.BackColor = System.Drawing.Color.Gold
        Me.PictureBox116.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.pembatasgatetol
        Me.PictureBox116.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox116.Location = New System.Drawing.Point(541, 305)
        Me.PictureBox116.Name = "PictureBox116"
        Me.PictureBox116.Size = New System.Drawing.Size(65, 13)
        Me.PictureBox116.TabIndex = 275
        Me.PictureBox116.TabStop = False
        '
        'PictureBox62
        '
        Me.PictureBox62.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox62.Location = New System.Drawing.Point(573, 281)
        Me.PictureBox62.Name = "PictureBox62"
        Me.PictureBox62.Size = New System.Drawing.Size(44, 37)
        Me.PictureBox62.TabIndex = 208
        Me.PictureBox62.TabStop = False
        '
        'pctPALANGETOLL
        '
        Me.pctPALANGETOLL.BackColor = System.Drawing.Color.Yellow
        Me.pctPALANGETOLL.Location = New System.Drawing.Point(728, 223)
        Me.pctPALANGETOLL.Name = "pctPALANGETOLL"
        Me.pctPALANGETOLL.Size = New System.Drawing.Size(10, 55)
        Me.pctPALANGETOLL.TabIndex = 228
        Me.pctPALANGETOLL.TabStop = False
        '
        'PictureBox117
        '
        Me.PictureBox117.BackColor = System.Drawing.Color.Gold
        Me.PictureBox117.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.pembatasgatetol
        Me.PictureBox117.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox117.Location = New System.Drawing.Point(661, 305)
        Me.PictureBox117.Name = "PictureBox117"
        Me.PictureBox117.Size = New System.Drawing.Size(65, 13)
        Me.PictureBox117.TabIndex = 277
        Me.PictureBox117.TabStop = False
        '
        'PictureBox55
        '
        Me.PictureBox55.BackColor = System.Drawing.Color.Silver
        Me.PictureBox55.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.gerbang_out
        Me.PictureBox55.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox55.Location = New System.Drawing.Point(612, 256)
        Me.PictureBox55.Name = "PictureBox55"
        Me.PictureBox55.Size = New System.Drawing.Size(77, 62)
        Me.PictureBox55.TabIndex = 201
        Me.PictureBox55.TabStop = False
        '
        'PictureBox60
        '
        Me.PictureBox60.BackColor = System.Drawing.Color.Gold
        Me.PictureBox60.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.pembatasgatetol
        Me.PictureBox60.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox60.Location = New System.Drawing.Point(556, 240)
        Me.PictureBox60.Name = "PictureBox60"
        Me.PictureBox60.Size = New System.Drawing.Size(55, 10)
        Me.PictureBox60.TabIndex = 281
        Me.PictureBox60.TabStop = False
        '
        'pctETOLL
        '
        Me.pctETOLL.BackColor = System.Drawing.Color.Silver
        Me.pctETOLL.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.mobilitem
        Me.pctETOLL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pctETOLL.Location = New System.Drawing.Point(12, 256)
        Me.pctETOLL.Name = "pctETOLL"
        Me.pctETOLL.Size = New System.Drawing.Size(118, 40)
        Me.pctETOLL.TabIndex = 345
        Me.pctETOLL.TabStop = False
        '
        'PictureBox150
        '
        Me.PictureBox150.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox150.Location = New System.Drawing.Point(563, 337)
        Me.PictureBox150.Name = "PictureBox150"
        Me.PictureBox150.Size = New System.Drawing.Size(48, 35)
        Me.PictureBox150.TabIndex = 338
        Me.PictureBox150.TabStop = False
        '
        'PictureBox148
        '
        Me.PictureBox148.BackColor = System.Drawing.Color.Silver
        Me.PictureBox148.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.icon_31883_960_720
        Me.PictureBox148.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox148.Location = New System.Drawing.Point(492, 230)
        Me.PictureBox148.Name = "PictureBox148"
        Me.PictureBox148.Size = New System.Drawing.Size(11, 14)
        Me.PictureBox148.TabIndex = 336
        Me.PictureBox148.TabStop = False
        '
        'PictureBox68
        '
        Me.PictureBox68.BackColor = System.Drawing.Color.White
        Me.PictureBox68.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.icon_31883_960_720
        Me.PictureBox68.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox68.Location = New System.Drawing.Point(355, 230)
        Me.PictureBox68.Name = "PictureBox68"
        Me.PictureBox68.Size = New System.Drawing.Size(11, 14)
        Me.PictureBox68.TabIndex = 335
        Me.PictureBox68.TabStop = False
        '
        'PictureBox70
        '
        Me.PictureBox70.BackColor = System.Drawing.Color.White
        Me.PictureBox70.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.icon_31883_960_720
        Me.PictureBox70.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox70.Location = New System.Drawing.Point(447, 230)
        Me.PictureBox70.Name = "PictureBox70"
        Me.PictureBox70.Size = New System.Drawing.Size(11, 14)
        Me.PictureBox70.TabIndex = 334
        Me.PictureBox70.TabStop = False
        '
        'PictureBox87
        '
        Me.PictureBox87.BackColor = System.Drawing.Color.White
        Me.PictureBox87.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.icon_31883_960_720
        Me.PictureBox87.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox87.Location = New System.Drawing.Point(401, 230)
        Me.PictureBox87.Name = "PictureBox87"
        Me.PictureBox87.Size = New System.Drawing.Size(11, 14)
        Me.PictureBox87.TabIndex = 333
        Me.PictureBox87.TabStop = False
        '
        'PictureBox139
        '
        Me.PictureBox139.BackColor = System.Drawing.Color.Silver
        Me.PictureBox139.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.icon_31883_960_720
        Me.PictureBox139.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox139.Location = New System.Drawing.Point(379, 230)
        Me.PictureBox139.Name = "PictureBox139"
        Me.PictureBox139.Size = New System.Drawing.Size(11, 14)
        Me.PictureBox139.TabIndex = 332
        Me.PictureBox139.TabStop = False
        '
        'PictureBox140
        '
        Me.PictureBox140.BackColor = System.Drawing.Color.Silver
        Me.PictureBox140.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.icon_31883_960_720
        Me.PictureBox140.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox140.Location = New System.Drawing.Point(424, 230)
        Me.PictureBox140.Name = "PictureBox140"
        Me.PictureBox140.Size = New System.Drawing.Size(11, 14)
        Me.PictureBox140.TabIndex = 331
        Me.PictureBox140.TabStop = False
        '
        'PictureBox141
        '
        Me.PictureBox141.BackColor = System.Drawing.Color.Silver
        Me.PictureBox141.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.icon_31883_960_720
        Me.PictureBox141.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox141.Location = New System.Drawing.Point(469, 230)
        Me.PictureBox141.Name = "PictureBox141"
        Me.PictureBox141.Size = New System.Drawing.Size(11, 14)
        Me.PictureBox141.TabIndex = 330
        Me.PictureBox141.TabStop = False
        '
        'pctMOBILAPT
        '
        Me.pctMOBILAPT.BackColor = System.Drawing.Color.Silver
        Me.pctMOBILAPT.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.mobilAPT
        Me.pctMOBILAPT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pctMOBILAPT.Location = New System.Drawing.Point(12, 326)
        Me.pctMOBILAPT.Name = "pctMOBILAPT"
        Me.pctMOBILAPT.Size = New System.Drawing.Size(118, 44)
        Me.pctMOBILAPT.TabIndex = 232
        Me.pctMOBILAPT.TabStop = False
        '
        'PictureBox138
        '
        Me.PictureBox138.BackColor = System.Drawing.Color.White
        Me.PictureBox138.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox138.Location = New System.Drawing.Point(297, 310)
        Me.PictureBox138.Name = "PictureBox138"
        Me.PictureBox138.Size = New System.Drawing.Size(186, 10)
        Me.PictureBox138.TabIndex = 313
        Me.PictureBox138.TabStop = False
        '
        'PictureBox137
        '
        Me.PictureBox137.BackColor = System.Drawing.Color.White
        Me.PictureBox137.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox137.Location = New System.Drawing.Point(296, 240)
        Me.PictureBox137.Name = "PictureBox137"
        Me.PictureBox137.Size = New System.Drawing.Size(208, 10)
        Me.PictureBox137.TabIndex = 312
        Me.PictureBox137.TabStop = False
        '
        'PictureBox135
        '
        Me.PictureBox135.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox135.Location = New System.Drawing.Point(587, 231)
        Me.PictureBox135.Name = "PictureBox135"
        Me.PictureBox135.Size = New System.Drawing.Size(10, 10)
        Me.PictureBox135.TabIndex = 311
        Me.PictureBox135.TabStop = False
        '
        'PictureBox136
        '
        Me.PictureBox136.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox136.Location = New System.Drawing.Point(542, 231)
        Me.PictureBox136.Name = "PictureBox136"
        Me.PictureBox136.Size = New System.Drawing.Size(10, 10)
        Me.PictureBox136.TabIndex = 310
        Me.PictureBox136.TabStop = False
        '
        'PictureBox134
        '
        Me.PictureBox134.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox134.Location = New System.Drawing.Point(547, 292)
        Me.PictureBox134.Name = "PictureBox134"
        Me.PictureBox134.Size = New System.Drawing.Size(10, 14)
        Me.PictureBox134.TabIndex = 308
        Me.PictureBox134.TabStop = False
        '
        'PictureBox133
        '
        Me.PictureBox133.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox133.Location = New System.Drawing.Point(502, 292)
        Me.PictureBox133.Name = "PictureBox133"
        Me.PictureBox133.Size = New System.Drawing.Size(10, 14)
        Me.PictureBox133.TabIndex = 307
        Me.PictureBox133.TabStop = False
        '
        'PictureBox132
        '
        Me.PictureBox132.BackColor = System.Drawing.Color.White
        Me.PictureBox132.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox132.Location = New System.Drawing.Point(1329, 240)
        Me.PictureBox132.Name = "PictureBox132"
        Me.PictureBox132.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox132.TabIndex = 305
        Me.PictureBox132.TabStop = False
        '
        'PictureBox131
        '
        Me.PictureBox131.BackColor = System.Drawing.Color.White
        Me.PictureBox131.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox131.Location = New System.Drawing.Point(1209, 240)
        Me.PictureBox131.Name = "PictureBox131"
        Me.PictureBox131.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox131.TabIndex = 304
        Me.PictureBox131.TabStop = False
        '
        'PictureBox130
        '
        Me.PictureBox130.BackColor = System.Drawing.Color.White
        Me.PictureBox130.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox130.Location = New System.Drawing.Point(1095, 240)
        Me.PictureBox130.Name = "PictureBox130"
        Me.PictureBox130.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox130.TabIndex = 303
        Me.PictureBox130.TabStop = False
        '
        'PictureBox129
        '
        Me.PictureBox129.BackColor = System.Drawing.Color.White
        Me.PictureBox129.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox129.Location = New System.Drawing.Point(1341, 310)
        Me.PictureBox129.Name = "PictureBox129"
        Me.PictureBox129.Size = New System.Drawing.Size(27, 10)
        Me.PictureBox129.TabIndex = 302
        Me.PictureBox129.TabStop = False
        '
        'PictureBox128
        '
        Me.PictureBox128.BackColor = System.Drawing.Color.White
        Me.PictureBox128.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox128.Location = New System.Drawing.Point(1244, 310)
        Me.PictureBox128.Name = "PictureBox128"
        Me.PictureBox128.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox128.TabIndex = 301
        Me.PictureBox128.TabStop = False
        '
        'PictureBox127
        '
        Me.PictureBox127.BackColor = System.Drawing.Color.White
        Me.PictureBox127.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox127.Location = New System.Drawing.Point(1143, 310)
        Me.PictureBox127.Name = "PictureBox127"
        Me.PictureBox127.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox127.TabIndex = 300
        Me.PictureBox127.TabStop = False
        '
        'PictureBox125
        '
        Me.PictureBox125.BackColor = System.Drawing.Color.White
        Me.PictureBox125.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox125.Location = New System.Drawing.Point(767, 242)
        Me.PictureBox125.Name = "PictureBox125"
        Me.PictureBox125.Size = New System.Drawing.Size(213, 10)
        Me.PictureBox125.TabIndex = 294
        Me.PictureBox125.TabStop = False
        '
        'PictureBox124
        '
        Me.PictureBox124.BackColor = System.Drawing.Color.White
        Me.PictureBox124.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox124.Location = New System.Drawing.Point(851, 310)
        Me.PictureBox124.Name = "PictureBox124"
        Me.PictureBox124.Size = New System.Drawing.Size(236, 10)
        Me.PictureBox124.TabIndex = 293
        Me.PictureBox124.TabStop = False
        '
        'PictureBox123
        '
        Me.PictureBox123.BackColor = System.Drawing.Color.Gold
        Me.PictureBox123.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.pembatasgatetol
        Me.PictureBox123.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox123.Location = New System.Drawing.Point(716, 240)
        Me.PictureBox123.Name = "PictureBox123"
        Me.PictureBox123.Size = New System.Drawing.Size(55, 10)
        Me.PictureBox123.TabIndex = 285
        Me.PictureBox123.TabStop = False
        '
        'PictureBox120
        '
        Me.PictureBox120.BackColor = System.Drawing.Color.Silver
        Me.PictureBox120.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.pembatasgatetol2
        Me.PictureBox120.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox120.Location = New System.Drawing.Point(502, 240)
        Me.PictureBox120.Name = "PictureBox120"
        Me.PictureBox120.Size = New System.Drawing.Size(55, 10)
        Me.PictureBox120.TabIndex = 280
        Me.PictureBox120.TabStop = False
        '
        'PictureBox119
        '
        Me.PictureBox119.BackColor = System.Drawing.Color.Gold
        Me.PictureBox119.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.pembatasgatetol
        Me.PictureBox119.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox119.Location = New System.Drawing.Point(788, 305)
        Me.PictureBox119.Name = "PictureBox119"
        Me.PictureBox119.Size = New System.Drawing.Size(65, 13)
        Me.PictureBox119.TabIndex = 279
        Me.PictureBox119.TabStop = False
        '
        'PictureBox118
        '
        Me.PictureBox118.BackColor = System.Drawing.Color.Gold
        Me.PictureBox118.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.pembatasgatetol
        Me.PictureBox118.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox118.Location = New System.Drawing.Point(724, 305)
        Me.PictureBox118.Name = "PictureBox118"
        Me.PictureBox118.Size = New System.Drawing.Size(65, 13)
        Me.PictureBox118.TabIndex = 278
        Me.PictureBox118.TabStop = False
        '
        'PictureBox90
        '
        Me.PictureBox90.BackColor = System.Drawing.Color.White
        Me.PictureBox90.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox90.Location = New System.Drawing.Point(43, 524)
        Me.PictureBox90.Name = "PictureBox90"
        Me.PictureBox90.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox90.TabIndex = 274
        Me.PictureBox90.TabStop = False
        '
        'PictureBox91
        '
        Me.PictureBox91.BackColor = System.Drawing.Color.White
        Me.PictureBox91.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox91.Location = New System.Drawing.Point(154, 524)
        Me.PictureBox91.Name = "PictureBox91"
        Me.PictureBox91.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox91.TabIndex = 273
        Me.PictureBox91.TabStop = False
        '
        'PictureBox92
        '
        Me.PictureBox92.BackColor = System.Drawing.Color.White
        Me.PictureBox92.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox92.Location = New System.Drawing.Point(260, 524)
        Me.PictureBox92.Name = "PictureBox92"
        Me.PictureBox92.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox92.TabIndex = 272
        Me.PictureBox92.TabStop = False
        '
        'PictureBox93
        '
        Me.PictureBox93.BackColor = System.Drawing.Color.White
        Me.PictureBox93.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox93.Location = New System.Drawing.Point(368, 524)
        Me.PictureBox93.Name = "PictureBox93"
        Me.PictureBox93.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox93.TabIndex = 271
        Me.PictureBox93.TabStop = False
        '
        'PictureBox94
        '
        Me.PictureBox94.BackColor = System.Drawing.Color.White
        Me.PictureBox94.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox94.Location = New System.Drawing.Point(475, 524)
        Me.PictureBox94.Name = "PictureBox94"
        Me.PictureBox94.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox94.TabIndex = 270
        Me.PictureBox94.TabStop = False
        '
        'PictureBox95
        '
        Me.PictureBox95.BackColor = System.Drawing.Color.White
        Me.PictureBox95.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox95.Location = New System.Drawing.Point(581, 524)
        Me.PictureBox95.Name = "PictureBox95"
        Me.PictureBox95.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox95.TabIndex = 269
        Me.PictureBox95.TabStop = False
        '
        'PictureBox96
        '
        Me.PictureBox96.BackColor = System.Drawing.Color.White
        Me.PictureBox96.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox96.Location = New System.Drawing.Point(686, 524)
        Me.PictureBox96.Name = "PictureBox96"
        Me.PictureBox96.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox96.TabIndex = 268
        Me.PictureBox96.TabStop = False
        '
        'PictureBox97
        '
        Me.PictureBox97.BackColor = System.Drawing.Color.White
        Me.PictureBox97.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox97.Location = New System.Drawing.Point(792, 524)
        Me.PictureBox97.Name = "PictureBox97"
        Me.PictureBox97.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox97.TabIndex = 267
        Me.PictureBox97.TabStop = False
        '
        'PictureBox98
        '
        Me.PictureBox98.BackColor = System.Drawing.Color.White
        Me.PictureBox98.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox98.Location = New System.Drawing.Point(899, 524)
        Me.PictureBox98.Name = "PictureBox98"
        Me.PictureBox98.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox98.TabIndex = 266
        Me.PictureBox98.TabStop = False
        '
        'PictureBox99
        '
        Me.PictureBox99.BackColor = System.Drawing.Color.White
        Me.PictureBox99.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox99.Location = New System.Drawing.Point(1002, 524)
        Me.PictureBox99.Name = "PictureBox99"
        Me.PictureBox99.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox99.TabIndex = 265
        Me.PictureBox99.TabStop = False
        '
        'PictureBox100
        '
        Me.PictureBox100.BackColor = System.Drawing.Color.White
        Me.PictureBox100.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox100.Location = New System.Drawing.Point(1106, 524)
        Me.PictureBox100.Name = "PictureBox100"
        Me.PictureBox100.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox100.TabIndex = 264
        Me.PictureBox100.TabStop = False
        '
        'PictureBox101
        '
        Me.PictureBox101.BackColor = System.Drawing.Color.White
        Me.PictureBox101.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox101.Location = New System.Drawing.Point(1209, 524)
        Me.PictureBox101.Name = "PictureBox101"
        Me.PictureBox101.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox101.TabIndex = 263
        Me.PictureBox101.TabStop = False
        '
        'PictureBox102
        '
        Me.PictureBox102.BackColor = System.Drawing.Color.White
        Me.PictureBox102.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox102.Location = New System.Drawing.Point(1310, 524)
        Me.PictureBox102.Name = "PictureBox102"
        Me.PictureBox102.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox102.TabIndex = 262
        Me.PictureBox102.TabStop = False
        '
        'PictureBox103
        '
        Me.PictureBox103.BackColor = System.Drawing.Color.White
        Me.PictureBox103.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox103.Location = New System.Drawing.Point(43, 595)
        Me.PictureBox103.Name = "PictureBox103"
        Me.PictureBox103.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox103.TabIndex = 261
        Me.PictureBox103.TabStop = False
        '
        'PictureBox104
        '
        Me.PictureBox104.BackColor = System.Drawing.Color.White
        Me.PictureBox104.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox104.Location = New System.Drawing.Point(154, 595)
        Me.PictureBox104.Name = "PictureBox104"
        Me.PictureBox104.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox104.TabIndex = 260
        Me.PictureBox104.TabStop = False
        '
        'PictureBox105
        '
        Me.PictureBox105.BackColor = System.Drawing.Color.White
        Me.PictureBox105.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox105.Location = New System.Drawing.Point(260, 595)
        Me.PictureBox105.Name = "PictureBox105"
        Me.PictureBox105.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox105.TabIndex = 259
        Me.PictureBox105.TabStop = False
        '
        'PictureBox106
        '
        Me.PictureBox106.BackColor = System.Drawing.Color.White
        Me.PictureBox106.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox106.Location = New System.Drawing.Point(368, 595)
        Me.PictureBox106.Name = "PictureBox106"
        Me.PictureBox106.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox106.TabIndex = 258
        Me.PictureBox106.TabStop = False
        '
        'PictureBox107
        '
        Me.PictureBox107.BackColor = System.Drawing.Color.White
        Me.PictureBox107.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox107.Location = New System.Drawing.Point(475, 595)
        Me.PictureBox107.Name = "PictureBox107"
        Me.PictureBox107.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox107.TabIndex = 257
        Me.PictureBox107.TabStop = False
        '
        'PictureBox108
        '
        Me.PictureBox108.BackColor = System.Drawing.Color.White
        Me.PictureBox108.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox108.Location = New System.Drawing.Point(581, 595)
        Me.PictureBox108.Name = "PictureBox108"
        Me.PictureBox108.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox108.TabIndex = 256
        Me.PictureBox108.TabStop = False
        '
        'PictureBox109
        '
        Me.PictureBox109.BackColor = System.Drawing.Color.White
        Me.PictureBox109.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox109.Location = New System.Drawing.Point(686, 595)
        Me.PictureBox109.Name = "PictureBox109"
        Me.PictureBox109.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox109.TabIndex = 255
        Me.PictureBox109.TabStop = False
        '
        'PictureBox110
        '
        Me.PictureBox110.BackColor = System.Drawing.Color.White
        Me.PictureBox110.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox110.Location = New System.Drawing.Point(792, 595)
        Me.PictureBox110.Name = "PictureBox110"
        Me.PictureBox110.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox110.TabIndex = 254
        Me.PictureBox110.TabStop = False
        '
        'PictureBox111
        '
        Me.PictureBox111.BackColor = System.Drawing.Color.White
        Me.PictureBox111.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox111.Location = New System.Drawing.Point(899, 595)
        Me.PictureBox111.Name = "PictureBox111"
        Me.PictureBox111.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox111.TabIndex = 253
        Me.PictureBox111.TabStop = False
        '
        'PictureBox112
        '
        Me.PictureBox112.BackColor = System.Drawing.Color.White
        Me.PictureBox112.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox112.Location = New System.Drawing.Point(1002, 595)
        Me.PictureBox112.Name = "PictureBox112"
        Me.PictureBox112.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox112.TabIndex = 252
        Me.PictureBox112.TabStop = False
        '
        'PictureBox113
        '
        Me.PictureBox113.BackColor = System.Drawing.Color.White
        Me.PictureBox113.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox113.Location = New System.Drawing.Point(1106, 595)
        Me.PictureBox113.Name = "PictureBox113"
        Me.PictureBox113.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox113.TabIndex = 251
        Me.PictureBox113.TabStop = False
        '
        'PictureBox114
        '
        Me.PictureBox114.BackColor = System.Drawing.Color.White
        Me.PictureBox114.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox114.Location = New System.Drawing.Point(1209, 595)
        Me.PictureBox114.Name = "PictureBox114"
        Me.PictureBox114.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox114.TabIndex = 250
        Me.PictureBox114.TabStop = False
        '
        'PictureBox115
        '
        Me.PictureBox115.BackColor = System.Drawing.Color.White
        Me.PictureBox115.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox115.Location = New System.Drawing.Point(1310, 595)
        Me.PictureBox115.Name = "PictureBox115"
        Me.PictureBox115.Size = New System.Drawing.Size(51, 10)
        Me.PictureBox115.TabIndex = 249
        Me.PictureBox115.TabStop = False
        '
        'PictureBox88
        '
        Me.PictureBox88.BackColor = System.Drawing.Color.Gray
        Me.PictureBox88.Location = New System.Drawing.Point(-4, 186)
        Me.PictureBox88.Name = "PictureBox88"
        Me.PictureBox88.Size = New System.Drawing.Size(1373, 10)
        Me.PictureBox88.TabIndex = 234
        Me.PictureBox88.TabStop = False
        '
        'PictureBox86
        '
        Me.PictureBox86.BackColor = System.Drawing.Color.White
        Me.PictureBox86.Location = New System.Drawing.Point(781, 318)
        Me.PictureBox86.Name = "PictureBox86"
        Me.PictureBox86.Size = New System.Drawing.Size(10, 54)
        Me.PictureBox86.TabIndex = 231
        Me.PictureBox86.TabStop = False
        '
        'PictureBox85
        '
        Me.PictureBox85.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox85.Location = New System.Drawing.Point(725, 215)
        Me.PictureBox85.Name = "PictureBox85"
        Me.PictureBox85.Size = New System.Drawing.Size(17, 26)
        Me.PictureBox85.TabIndex = 230
        Me.PictureBox85.TabStop = False
        '
        'PictureBox79
        '
        Me.PictureBox79.BackColor = System.Drawing.Color.White
        Me.PictureBox79.Location = New System.Drawing.Point(654, 249)
        Me.PictureBox79.Name = "PictureBox79"
        Me.PictureBox79.Size = New System.Drawing.Size(10, 11)
        Me.PictureBox79.TabIndex = 224
        Me.PictureBox79.TabStop = False
        '
        'PictureBox57
        '
        Me.PictureBox57.BackColor = System.Drawing.Color.Silver
        Me.PictureBox57.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.pembatasgatetol2
        Me.PictureBox57.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox57.Location = New System.Drawing.Point(479, 305)
        Me.PictureBox57.Name = "PictureBox57"
        Me.PictureBox57.Size = New System.Drawing.Size(65, 13)
        Me.PictureBox57.TabIndex = 204
        Me.PictureBox57.TabStop = False
        '
        'PictureBox77
        '
        Me.PictureBox77.BackColor = System.Drawing.Color.White
        Me.PictureBox77.Location = New System.Drawing.Point(401, 208)
        Me.PictureBox77.Name = "PictureBox77"
        Me.PictureBox77.Size = New System.Drawing.Size(10, 165)
        Me.PictureBox77.TabIndex = 222
        Me.PictureBox77.TabStop = False
        '
        'PictureBox76
        '
        Me.PictureBox76.BackColor = System.Drawing.Color.White
        Me.PictureBox76.Location = New System.Drawing.Point(701, 317)
        Me.PictureBox76.Name = "PictureBox76"
        Me.PictureBox76.Size = New System.Drawing.Size(10, 54)
        Me.PictureBox76.TabIndex = 221
        Me.PictureBox76.TabStop = False
        '
        'PictureBox74
        '
        Me.PictureBox74.BackColor = System.Drawing.Color.White
        Me.PictureBox74.Location = New System.Drawing.Point(617, 318)
        Me.PictureBox74.Name = "PictureBox74"
        Me.PictureBox74.Size = New System.Drawing.Size(10, 54)
        Me.PictureBox74.TabIndex = 220
        Me.PictureBox74.TabStop = False
        '
        'PictureBox73
        '
        Me.PictureBox73.BackColor = System.Drawing.Color.White
        Me.PictureBox73.Location = New System.Drawing.Point(355, 208)
        Me.PictureBox73.Name = "PictureBox73"
        Me.PictureBox73.Size = New System.Drawing.Size(10, 164)
        Me.PictureBox73.TabIndex = 219
        Me.PictureBox73.TabStop = False
        '
        'PictureBox72
        '
        Me.PictureBox72.BackColor = System.Drawing.Color.White
        Me.PictureBox72.Location = New System.Drawing.Point(740, 318)
        Me.PictureBox72.Name = "PictureBox72"
        Me.PictureBox72.Size = New System.Drawing.Size(10, 54)
        Me.PictureBox72.TabIndex = 218
        Me.PictureBox72.TabStop = False
        '
        'PictureBox71
        '
        Me.PictureBox71.BackColor = System.Drawing.Color.White
        Me.PictureBox71.Location = New System.Drawing.Point(661, 318)
        Me.PictureBox71.Name = "PictureBox71"
        Me.PictureBox71.Size = New System.Drawing.Size(10, 54)
        Me.PictureBox71.TabIndex = 217
        Me.PictureBox71.TabStop = False
        '
        'PictureBox69
        '
        Me.PictureBox69.BackColor = System.Drawing.Color.White
        Me.PictureBox69.Location = New System.Drawing.Point(447, 203)
        Me.PictureBox69.Name = "PictureBox69"
        Me.PictureBox69.Size = New System.Drawing.Size(10, 169)
        Me.PictureBox69.TabIndex = 215
        Me.PictureBox69.TabStop = False
        '
        'pctMLAMA
        '
        Me.pctMLAMA.BackColor = System.Drawing.Color.Silver
        Me.pctMLAMA.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.mobilijo
        Me.pctMLAMA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pctMLAMA.Location = New System.Drawing.Point(1316, 612)
        Me.pctMLAMA.Name = "pctMLAMA"
        Me.pctMLAMA.Size = New System.Drawing.Size(133, 52)
        Me.pctMLAMA.TabIndex = 195
        Me.pctMLAMA.TabStop = False
        '
        'pctMBIASA
        '
        Me.pctMBIASA.BackColor = System.Drawing.Color.Silver
        Me.pctMBIASA.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.mobil21
        Me.pctMBIASA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pctMBIASA.Location = New System.Drawing.Point(1316, 537)
        Me.pctMBIASA.Name = "pctMBIASA"
        Me.pctMBIASA.Size = New System.Drawing.Size(133, 52)
        Me.pctMBIASA.TabIndex = 194
        Me.pctMBIASA.TabStop = False
        '
        'pctSPORT
        '
        Me.pctSPORT.BackColor = System.Drawing.Color.Silver
        Me.pctSPORT.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.mobilsport1
        Me.pctSPORT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pctSPORT.Location = New System.Drawing.Point(1316, 462)
        Me.pctSPORT.Name = "pctSPORT"
        Me.pctSPORT.Size = New System.Drawing.Size(133, 59)
        Me.pctSPORT.TabIndex = 193
        Me.pctSPORT.TabStop = False
        '
        'pctMOBILPOL
        '
        Me.pctMOBILPOL.BackColor = System.Drawing.Color.Silver
        Me.pctMOBILPOL.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.mobilpol1
        Me.pctMOBILPOL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pctMOBILPOL.Location = New System.Drawing.Point(1316, 681)
        Me.pctMOBILPOL.Name = "pctMOBILPOL"
        Me.pctMOBILPOL.Size = New System.Drawing.Size(125, 48)
        Me.pctMOBILPOL.TabIndex = 192
        Me.pctMOBILPOL.TabStop = False
        '
        'PictureBox75
        '
        Me.PictureBox75.BackColor = System.Drawing.Color.White
        Me.PictureBox75.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox75.Location = New System.Drawing.Point(-4, 670)
        Me.PictureBox75.Name = "PictureBox75"
        Me.PictureBox75.Size = New System.Drawing.Size(1372, 10)
        Me.PictureBox75.TabIndex = 191
        Me.PictureBox75.TabStop = False
        '
        'PictureBox54
        '
        Me.PictureBox54.BackColor = System.Drawing.Color.Lime
        Me.PictureBox54.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.bush_151473_640
        Me.PictureBox54.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox54.Location = New System.Drawing.Point(1310, 401)
        Me.PictureBox54.Name = "PictureBox54"
        Me.PictureBox54.Size = New System.Drawing.Size(33, 30)
        Me.PictureBox54.TabIndex = 190
        Me.PictureBox54.TabStop = False
        '
        'PictureBox53
        '
        Me.PictureBox53.BackColor = System.Drawing.Color.Lime
        Me.PictureBox53.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.bush_151473_640
        Me.PictureBox53.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox53.Location = New System.Drawing.Point(1193, 401)
        Me.PictureBox53.Name = "PictureBox53"
        Me.PictureBox53.Size = New System.Drawing.Size(33, 30)
        Me.PictureBox53.TabIndex = 189
        Me.PictureBox53.TabStop = False
        '
        'PictureBox52
        '
        Me.PictureBox52.BackColor = System.Drawing.Color.Lime
        Me.PictureBox52.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.bush_151473_640
        Me.PictureBox52.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox52.Location = New System.Drawing.Point(1067, 401)
        Me.PictureBox52.Name = "PictureBox52"
        Me.PictureBox52.Size = New System.Drawing.Size(33, 30)
        Me.PictureBox52.TabIndex = 188
        Me.PictureBox52.TabStop = False
        '
        'PictureBox51
        '
        Me.PictureBox51.BackColor = System.Drawing.Color.Lime
        Me.PictureBox51.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.bush_151473_640
        Me.PictureBox51.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox51.Location = New System.Drawing.Point(937, 401)
        Me.PictureBox51.Name = "PictureBox51"
        Me.PictureBox51.Size = New System.Drawing.Size(33, 30)
        Me.PictureBox51.TabIndex = 187
        Me.PictureBox51.TabStop = False
        '
        'PictureBox50
        '
        Me.PictureBox50.BackColor = System.Drawing.Color.Lime
        Me.PictureBox50.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.bush_151473_640
        Me.PictureBox50.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox50.Location = New System.Drawing.Point(-4, 400)
        Me.PictureBox50.Name = "PictureBox50"
        Me.PictureBox50.Size = New System.Drawing.Size(33, 30)
        Me.PictureBox50.TabIndex = 186
        Me.PictureBox50.TabStop = False
        '
        'PictureBox49
        '
        Me.PictureBox49.BackColor = System.Drawing.Color.Lime
        Me.PictureBox49.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.bush_151473_640
        Me.PictureBox49.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox49.Location = New System.Drawing.Point(122, 401)
        Me.PictureBox49.Name = "PictureBox49"
        Me.PictureBox49.Size = New System.Drawing.Size(33, 30)
        Me.PictureBox49.TabIndex = 185
        Me.PictureBox49.TabStop = False
        '
        'PictureBox48
        '
        Me.PictureBox48.BackColor = System.Drawing.Color.Lime
        Me.PictureBox48.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.bush_151473_640
        Me.PictureBox48.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox48.Location = New System.Drawing.Point(235, 400)
        Me.PictureBox48.Name = "PictureBox48"
        Me.PictureBox48.Size = New System.Drawing.Size(33, 30)
        Me.PictureBox48.TabIndex = 184
        Me.PictureBox48.TabStop = False
        '
        'PictureBox47
        '
        Me.PictureBox47.BackColor = System.Drawing.Color.Lime
        Me.PictureBox47.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.bush_151473_640
        Me.PictureBox47.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox47.Location = New System.Drawing.Point(332, 401)
        Me.PictureBox47.Name = "PictureBox47"
        Me.PictureBox47.Size = New System.Drawing.Size(33, 30)
        Me.PictureBox47.TabIndex = 183
        Me.PictureBox47.TabStop = False
        '
        'PictureBox46
        '
        Me.PictureBox46.BackColor = System.Drawing.Color.Lime
        Me.PictureBox46.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.bush_151473_640
        Me.PictureBox46.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox46.Location = New System.Drawing.Point(805, 401)
        Me.PictureBox46.Name = "PictureBox46"
        Me.PictureBox46.Size = New System.Drawing.Size(33, 30)
        Me.PictureBox46.TabIndex = 182
        Me.PictureBox46.TabStop = False
        '
        'PictureBox45
        '
        Me.PictureBox45.BackColor = System.Drawing.Color.Lime
        Me.PictureBox45.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.bush_151473_640
        Me.PictureBox45.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox45.Location = New System.Drawing.Point(450, 400)
        Me.PictureBox45.Name = "PictureBox45"
        Me.PictureBox45.Size = New System.Drawing.Size(33, 30)
        Me.PictureBox45.TabIndex = 181
        Me.PictureBox45.TabStop = False
        '
        'PictureBox44
        '
        Me.PictureBox44.BackColor = System.Drawing.Color.Lime
        Me.PictureBox44.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.bush_151473_640
        Me.PictureBox44.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox44.Location = New System.Drawing.Point(563, 400)
        Me.PictureBox44.Name = "PictureBox44"
        Me.PictureBox44.Size = New System.Drawing.Size(33, 30)
        Me.PictureBox44.TabIndex = 180
        Me.PictureBox44.TabStop = False
        '
        'PictureBox43
        '
        Me.PictureBox43.BackColor = System.Drawing.Color.Lime
        Me.PictureBox43.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.bush_151473_640
        Me.PictureBox43.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox43.Location = New System.Drawing.Point(678, 400)
        Me.PictureBox43.Name = "PictureBox43"
        Me.PictureBox43.Size = New System.Drawing.Size(33, 30)
        Me.PictureBox43.TabIndex = 179
        Me.PictureBox43.TabStop = False
        '
        'PictureBox42
        '
        Me.PictureBox42.BackColor = System.Drawing.Color.White
        Me.PictureBox42.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.green_wheat_grass_tuft_hi1
        Me.PictureBox42.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox42.Location = New System.Drawing.Point(1262, 384)
        Me.PictureBox42.Name = "PictureBox42"
        Me.PictureBox42.Size = New System.Drawing.Size(42, 30)
        Me.PictureBox42.TabIndex = 178
        Me.PictureBox42.TabStop = False
        '
        'PictureBox41
        '
        Me.PictureBox41.BackColor = System.Drawing.Color.White
        Me.PictureBox41.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.green_wheat_grass_tuft_hi1
        Me.PictureBox41.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox41.Location = New System.Drawing.Point(1126, 384)
        Me.PictureBox41.Name = "PictureBox41"
        Me.PictureBox41.Size = New System.Drawing.Size(42, 30)
        Me.PictureBox41.TabIndex = 177
        Me.PictureBox41.TabStop = False
        '
        'PictureBox40
        '
        Me.PictureBox40.BackColor = System.Drawing.Color.White
        Me.PictureBox40.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.green_wheat_grass_tuft_hi1
        Me.PictureBox40.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox40.Location = New System.Drawing.Point(998, 384)
        Me.PictureBox40.Name = "PictureBox40"
        Me.PictureBox40.Size = New System.Drawing.Size(42, 30)
        Me.PictureBox40.TabIndex = 176
        Me.PictureBox40.TabStop = False
        '
        'PictureBox39
        '
        Me.PictureBox39.BackColor = System.Drawing.Color.White
        Me.PictureBox39.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.green_wheat_grass_tuft_hi1
        Me.PictureBox39.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox39.Location = New System.Drawing.Point(863, 384)
        Me.PictureBox39.Name = "PictureBox39"
        Me.PictureBox39.Size = New System.Drawing.Size(42, 30)
        Me.PictureBox39.TabIndex = 175
        Me.PictureBox39.TabStop = False
        '
        'PictureBox38
        '
        Me.PictureBox38.BackColor = System.Drawing.Color.White
        Me.PictureBox38.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.green_wheat_grass_tuft_hi1
        Me.PictureBox38.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox38.Location = New System.Drawing.Point(740, 384)
        Me.PictureBox38.Name = "PictureBox38"
        Me.PictureBox38.Size = New System.Drawing.Size(42, 30)
        Me.PictureBox38.TabIndex = 174
        Me.PictureBox38.TabStop = False
        '
        'PictureBox37
        '
        Me.PictureBox37.BackColor = System.Drawing.Color.White
        Me.PictureBox37.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.green_wheat_grass_tuft_hi1
        Me.PictureBox37.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox37.Location = New System.Drawing.Point(619, 384)
        Me.PictureBox37.Name = "PictureBox37"
        Me.PictureBox37.Size = New System.Drawing.Size(42, 30)
        Me.PictureBox37.TabIndex = 173
        Me.PictureBox37.TabStop = False
        '
        'PictureBox36
        '
        Me.PictureBox36.BackColor = System.Drawing.Color.White
        Me.PictureBox36.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.green_wheat_grass_tuft_hi1
        Me.PictureBox36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox36.Location = New System.Drawing.Point(502, 384)
        Me.PictureBox36.Name = "PictureBox36"
        Me.PictureBox36.Size = New System.Drawing.Size(42, 30)
        Me.PictureBox36.TabIndex = 172
        Me.PictureBox36.TabStop = False
        '
        'PictureBox35
        '
        Me.PictureBox35.BackColor = System.Drawing.Color.White
        Me.PictureBox35.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.green_wheat_grass_tuft_hi1
        Me.PictureBox35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox35.Location = New System.Drawing.Point(393, 384)
        Me.PictureBox35.Name = "PictureBox35"
        Me.PictureBox35.Size = New System.Drawing.Size(42, 30)
        Me.PictureBox35.TabIndex = 171
        Me.PictureBox35.TabStop = False
        '
        'PictureBox34
        '
        Me.PictureBox34.BackColor = System.Drawing.Color.White
        Me.PictureBox34.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.green_wheat_grass_tuft_hi1
        Me.PictureBox34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox34.Location = New System.Drawing.Point(284, 384)
        Me.PictureBox34.Name = "PictureBox34"
        Me.PictureBox34.Size = New System.Drawing.Size(42, 30)
        Me.PictureBox34.TabIndex = 170
        Me.PictureBox34.TabStop = False
        '
        'PictureBox33
        '
        Me.PictureBox33.BackColor = System.Drawing.Color.White
        Me.PictureBox33.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.green_wheat_grass_tuft_hi1
        Me.PictureBox33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox33.Location = New System.Drawing.Point(178, 384)
        Me.PictureBox33.Name = "PictureBox33"
        Me.PictureBox33.Size = New System.Drawing.Size(42, 30)
        Me.PictureBox33.TabIndex = 169
        Me.PictureBox33.TabStop = False
        '
        'PictureBox32
        '
        Me.PictureBox32.BackColor = System.Drawing.Color.White
        Me.PictureBox32.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.green_wheat_grass_tuft_hi1
        Me.PictureBox32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox32.Location = New System.Drawing.Point(60, 384)
        Me.PictureBox32.Name = "PictureBox32"
        Me.PictureBox32.Size = New System.Drawing.Size(42, 30)
        Me.PictureBox32.TabIndex = 168
        Me.PictureBox32.TabStop = False
        '
        'PictureBox31
        '
        Me.PictureBox31.BackColor = System.Drawing.Color.Gray
        Me.PictureBox31.Location = New System.Drawing.Point(1310, 436)
        Me.PictureBox31.Name = "PictureBox31"
        Me.PictureBox31.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox31.TabIndex = 167
        Me.PictureBox31.TabStop = False
        '
        'PictureBox30
        '
        Me.PictureBox30.BackColor = System.Drawing.Color.Gray
        Me.PictureBox30.Location = New System.Drawing.Point(1310, 371)
        Me.PictureBox30.Name = "PictureBox30"
        Me.PictureBox30.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox30.TabIndex = 166
        Me.PictureBox30.TabStop = False
        '
        'PictureBox29
        '
        Me.PictureBox29.BackColor = System.Drawing.Color.Gray
        Me.PictureBox29.Location = New System.Drawing.Point(1202, 371)
        Me.PictureBox29.Name = "PictureBox29"
        Me.PictureBox29.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox29.TabIndex = 165
        Me.PictureBox29.TabStop = False
        '
        'PictureBox28
        '
        Me.PictureBox28.BackColor = System.Drawing.Color.Gray
        Me.PictureBox28.Location = New System.Drawing.Point(1202, 436)
        Me.PictureBox28.Name = "PictureBox28"
        Me.PictureBox28.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox28.TabIndex = 164
        Me.PictureBox28.TabStop = False
        '
        'PictureBox27
        '
        Me.PictureBox27.BackColor = System.Drawing.Color.Gray
        Me.PictureBox27.Location = New System.Drawing.Point(1081, 436)
        Me.PictureBox27.Name = "PictureBox27"
        Me.PictureBox27.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox27.TabIndex = 163
        Me.PictureBox27.TabStop = False
        '
        'PictureBox26
        '
        Me.PictureBox26.BackColor = System.Drawing.Color.Gray
        Me.PictureBox26.Location = New System.Drawing.Point(948, 436)
        Me.PictureBox26.Name = "PictureBox26"
        Me.PictureBox26.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox26.TabIndex = 162
        Me.PictureBox26.TabStop = False
        '
        'PictureBox25
        '
        Me.PictureBox25.BackColor = System.Drawing.Color.Gray
        Me.PictureBox25.Location = New System.Drawing.Point(817, 436)
        Me.PictureBox25.Name = "PictureBox25"
        Me.PictureBox25.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox25.TabIndex = 161
        Me.PictureBox25.TabStop = False
        '
        'PictureBox24
        '
        Me.PictureBox24.BackColor = System.Drawing.Color.Gray
        Me.PictureBox24.Location = New System.Drawing.Point(1081, 371)
        Me.PictureBox24.Name = "PictureBox24"
        Me.PictureBox24.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox24.TabIndex = 160
        Me.PictureBox24.TabStop = False
        '
        'PictureBox23
        '
        Me.PictureBox23.BackColor = System.Drawing.Color.Gray
        Me.PictureBox23.Location = New System.Drawing.Point(690, 436)
        Me.PictureBox23.Name = "PictureBox23"
        Me.PictureBox23.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox23.TabIndex = 159
        Me.PictureBox23.TabStop = False
        '
        'PictureBox22
        '
        Me.PictureBox22.BackColor = System.Drawing.Color.Gray
        Me.PictureBox22.Location = New System.Drawing.Point(574, 371)
        Me.PictureBox22.Name = "PictureBox22"
        Me.PictureBox22.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox22.TabIndex = 158
        Me.PictureBox22.TabStop = False
        '
        'PictureBox21
        '
        Me.PictureBox21.BackColor = System.Drawing.Color.Gray
        Me.PictureBox21.Location = New System.Drawing.Point(574, 436)
        Me.PictureBox21.Name = "PictureBox21"
        Me.PictureBox21.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox21.TabIndex = 157
        Me.PictureBox21.TabStop = False
        '
        'PictureBox20
        '
        Me.PictureBox20.BackColor = System.Drawing.Color.Gray
        Me.PictureBox20.Location = New System.Drawing.Point(463, 371)
        Me.PictureBox20.Name = "PictureBox20"
        Me.PictureBox20.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox20.TabIndex = 156
        Me.PictureBox20.TabStop = False
        '
        'PictureBox19
        '
        Me.PictureBox19.BackColor = System.Drawing.Color.Gray
        Me.PictureBox19.Location = New System.Drawing.Point(463, 437)
        Me.PictureBox19.Name = "PictureBox19"
        Me.PictureBox19.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox19.TabIndex = 155
        Me.PictureBox19.TabStop = False
        '
        'PictureBox18
        '
        Me.PictureBox18.BackColor = System.Drawing.Color.Gray
        Me.PictureBox18.Location = New System.Drawing.Point(349, 437)
        Me.PictureBox18.Name = "PictureBox18"
        Me.PictureBox18.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox18.TabIndex = 154
        Me.PictureBox18.TabStop = False
        '
        'PictureBox17
        '
        Me.PictureBox17.BackColor = System.Drawing.Color.Gray
        Me.PictureBox17.Location = New System.Drawing.Point(246, 436)
        Me.PictureBox17.Name = "PictureBox17"
        Me.PictureBox17.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox17.TabIndex = 153
        Me.PictureBox17.TabStop = False
        '
        'PictureBox16
        '
        Me.PictureBox16.BackColor = System.Drawing.Color.Gray
        Me.PictureBox16.Location = New System.Drawing.Point(145, 437)
        Me.PictureBox16.Name = "PictureBox16"
        Me.PictureBox16.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox16.TabIndex = 152
        Me.PictureBox16.TabStop = False
        '
        'PictureBox15
        '
        Me.PictureBox15.BackColor = System.Drawing.Color.Gray
        Me.PictureBox15.Location = New System.Drawing.Point(44, 437)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox15.TabIndex = 151
        Me.PictureBox15.TabStop = False
        '
        'PictureBox14
        '
        Me.PictureBox14.BackColor = System.Drawing.Color.Gray
        Me.PictureBox14.Location = New System.Drawing.Point(349, 371)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox14.TabIndex = 150
        Me.PictureBox14.TabStop = False
        '
        'PictureBox13
        '
        Me.PictureBox13.BackColor = System.Drawing.Color.Gray
        Me.PictureBox13.Location = New System.Drawing.Point(246, 371)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox13.TabIndex = 149
        Me.PictureBox13.TabStop = False
        '
        'PictureBox12
        '
        Me.PictureBox12.BackColor = System.Drawing.Color.Gray
        Me.PictureBox12.Location = New System.Drawing.Point(145, 371)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox12.TabIndex = 148
        Me.PictureBox12.TabStop = False
        '
        'PictureBox11
        '
        Me.PictureBox11.BackColor = System.Drawing.Color.Gray
        Me.PictureBox11.Location = New System.Drawing.Point(44, 371)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox11.TabIndex = 147
        Me.PictureBox11.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.BackColor = System.Drawing.Color.Gray
        Me.PictureBox10.Location = New System.Drawing.Point(690, 371)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox10.TabIndex = 146
        Me.PictureBox10.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.BackColor = System.Drawing.Color.Gray
        Me.PictureBox9.Location = New System.Drawing.Point(817, 371)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox9.TabIndex = 145
        Me.PictureBox9.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.Color.Gray
        Me.PictureBox8.Location = New System.Drawing.Point(948, 371)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(10, 20)
        Me.PictureBox8.TabIndex = 144
        Me.PictureBox8.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.BackColor = System.Drawing.Color.Gray
        Me.PictureBox7.Location = New System.Drawing.Point(-4, 437)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(1384, 12)
        Me.PictureBox7.TabIndex = 143
        Me.PictureBox7.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Silver
        Me.PictureBox5.Location = New System.Drawing.Point(-4, 462)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(1384, 311)
        Me.PictureBox5.TabIndex = 141
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.Lime
        Me.PictureBox4.Location = New System.Drawing.Point(-4, 390)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(1384, 66)
        Me.PictureBox4.TabIndex = 140
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.SkyBlue
        Me.PictureBox3.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.city_buildings_png_transparent_images_clipart_icons_pngriver_download_free_infrastructure_img
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox3.Location = New System.Drawing.Point(-147, -5)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(807, 201)
        Me.PictureBox3.TabIndex = 139
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.SkyBlue
        Me.PictureBox2.BackgroundImage = Global.AutomatedTollPayment.My.Resources.Resources.city_buildings_png_transparent_images_clipart_icons_pngriver_download_free_infrastructure_img
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(598, -5)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(807, 201)
        Me.PictureBox2.TabIndex = 138
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Silver
        Me.PictureBox1.Location = New System.Drawing.Point(-15, 193)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1384, 191)
        Me.PictureBox1.TabIndex = 137
        Me.PictureBox1.TabStop = False
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(2, 3)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(45, 23)
        Me.Button7.TabIndex = 361
        Me.Button7.Text = "Show"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'tmrETOLL2
        '
        Me.tmrETOLL2.Interval = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(84, 78)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(84, 13)
        Me.Label5.TabIndex = 361
        Me.Label5.Text = "Toll Payment "
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(84, 94)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 13)
        Me.Label6.TabIndex = 361
        Me.Label6.Text = "Saldo Pulsa "
        '
        'Timer1
        '
        Me.Timer1.Interval = 500
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 730)
        Me.Controls.Add(Me.PictureBox134)
        Me.Controls.Add(Me.grpMOBIL)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox67)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.PictureBox66)
        Me.Controls.Add(Me.pctLAMPUETOLL)
        Me.Controls.Add(Me.PictureBox65)
        Me.Controls.Add(Me.PictureBox61)
        Me.Controls.Add(Me.PictureBox121)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.PictureBox58)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PictureBox56)
        Me.Controls.Add(Me.PictureBox89)
        Me.Controls.Add(Me.PictureBox64)
        Me.Controls.Add(Me.pctLORONG2)
        Me.Controls.Add(Me.pctLORONG1)
        Me.Controls.Add(Me.lblETOLL)
        Me.Controls.Add(Me.txtSTATUS)
        Me.Controls.Add(Me.palang)
        Me.Controls.Add(Me.PictureBox84)
        Me.Controls.Add(Me.LAMPUAPT)
        Me.Controls.Add(Me.PictureBox63)
        Me.Controls.Add(Me.PictureBox151)
        Me.Controls.Add(Me.PictureBox59)
        Me.Controls.Add(Me.PictureBox116)
        Me.Controls.Add(Me.PictureBox62)
        Me.Controls.Add(Me.labelgate)
        Me.Controls.Add(Me.pctPALANGETOLL)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.PictureBox117)
        Me.Controls.Add(Me.PictureBox55)
        Me.Controls.Add(Me.PictureBox60)
        Me.Controls.Add(Me.pctETOLL)
        Me.Controls.Add(Me.btnHIDE)
        Me.Controls.Add(Me.PictureBox150)
        Me.Controls.Add(Me.PictureBox148)
        Me.Controls.Add(Me.PictureBox68)
        Me.Controls.Add(Me.PictureBox70)
        Me.Controls.Add(Me.PictureBox87)
        Me.Controls.Add(Me.PictureBox139)
        Me.Controls.Add(Me.PictureBox140)
        Me.Controls.Add(Me.PictureBox141)
        Me.Controls.Add(Me.pctMOBILAPT)
        Me.Controls.Add(Me.PictureBox138)
        Me.Controls.Add(Me.PictureBox137)
        Me.Controls.Add(Me.PictureBox135)
        Me.Controls.Add(Me.PictureBox136)
        Me.Controls.Add(Me.PictureBox133)
        Me.Controls.Add(Me.PictureBox132)
        Me.Controls.Add(Me.PictureBox131)
        Me.Controls.Add(Me.PictureBox130)
        Me.Controls.Add(Me.PictureBox129)
        Me.Controls.Add(Me.PictureBox128)
        Me.Controls.Add(Me.PictureBox127)
        Me.Controls.Add(Me.lblgate)
        Me.Controls.Add(Me.PictureBox125)
        Me.Controls.Add(Me.PictureBox124)
        Me.Controls.Add(Me.PictureBox123)
        Me.Controls.Add(Me.PictureBox120)
        Me.Controls.Add(Me.PictureBox119)
        Me.Controls.Add(Me.PictureBox118)
        Me.Controls.Add(Me.PictureBox90)
        Me.Controls.Add(Me.PictureBox91)
        Me.Controls.Add(Me.PictureBox92)
        Me.Controls.Add(Me.PictureBox93)
        Me.Controls.Add(Me.PictureBox94)
        Me.Controls.Add(Me.PictureBox95)
        Me.Controls.Add(Me.PictureBox96)
        Me.Controls.Add(Me.PictureBox97)
        Me.Controls.Add(Me.PictureBox98)
        Me.Controls.Add(Me.PictureBox99)
        Me.Controls.Add(Me.PictureBox100)
        Me.Controls.Add(Me.PictureBox101)
        Me.Controls.Add(Me.PictureBox102)
        Me.Controls.Add(Me.PictureBox103)
        Me.Controls.Add(Me.PictureBox104)
        Me.Controls.Add(Me.PictureBox105)
        Me.Controls.Add(Me.PictureBox106)
        Me.Controls.Add(Me.PictureBox107)
        Me.Controls.Add(Me.PictureBox108)
        Me.Controls.Add(Me.PictureBox109)
        Me.Controls.Add(Me.PictureBox110)
        Me.Controls.Add(Me.PictureBox111)
        Me.Controls.Add(Me.PictureBox112)
        Me.Controls.Add(Me.PictureBox113)
        Me.Controls.Add(Me.PictureBox114)
        Me.Controls.Add(Me.PictureBox115)
        Me.Controls.Add(Me.PictureBox88)
        Me.Controls.Add(Me.PictureBox86)
        Me.Controls.Add(Me.PictureBox85)
        Me.Controls.Add(Me.PictureBox79)
        Me.Controls.Add(Me.PictureBox57)
        Me.Controls.Add(Me.PictureBox77)
        Me.Controls.Add(Me.PictureBox76)
        Me.Controls.Add(Me.PictureBox74)
        Me.Controls.Add(Me.PictureBox73)
        Me.Controls.Add(Me.PictureBox72)
        Me.Controls.Add(Me.PictureBox71)
        Me.Controls.Add(Me.PictureBox69)
        Me.Controls.Add(Me.pctMLAMA)
        Me.Controls.Add(Me.pctMBIASA)
        Me.Controls.Add(Me.pctSPORT)
        Me.Controls.Add(Me.pctMOBILPOL)
        Me.Controls.Add(Me.PictureBox75)
        Me.Controls.Add(Me.PictureBox54)
        Me.Controls.Add(Me.PictureBox53)
        Me.Controls.Add(Me.PictureBox52)
        Me.Controls.Add(Me.PictureBox51)
        Me.Controls.Add(Me.PictureBox50)
        Me.Controls.Add(Me.PictureBox49)
        Me.Controls.Add(Me.PictureBox48)
        Me.Controls.Add(Me.PictureBox47)
        Me.Controls.Add(Me.PictureBox46)
        Me.Controls.Add(Me.PictureBox45)
        Me.Controls.Add(Me.PictureBox44)
        Me.Controls.Add(Me.PictureBox43)
        Me.Controls.Add(Me.PictureBox42)
        Me.Controls.Add(Me.PictureBox41)
        Me.Controls.Add(Me.PictureBox40)
        Me.Controls.Add(Me.PictureBox39)
        Me.Controls.Add(Me.PictureBox38)
        Me.Controls.Add(Me.PictureBox37)
        Me.Controls.Add(Me.PictureBox36)
        Me.Controls.Add(Me.PictureBox35)
        Me.Controls.Add(Me.PictureBox34)
        Me.Controls.Add(Me.PictureBox33)
        Me.Controls.Add(Me.PictureBox32)
        Me.Controls.Add(Me.PictureBox31)
        Me.Controls.Add(Me.PictureBox30)
        Me.Controls.Add(Me.PictureBox29)
        Me.Controls.Add(Me.PictureBox28)
        Me.Controls.Add(Me.PictureBox27)
        Me.Controls.Add(Me.PictureBox26)
        Me.Controls.Add(Me.PictureBox25)
        Me.Controls.Add(Me.PictureBox24)
        Me.Controls.Add(Me.PictureBox23)
        Me.Controls.Add(Me.PictureBox22)
        Me.Controls.Add(Me.PictureBox21)
        Me.Controls.Add(Me.PictureBox20)
        Me.Controls.Add(Me.PictureBox19)
        Me.Controls.Add(Me.PictureBox18)
        Me.Controls.Add(Me.PictureBox17)
        Me.Controls.Add(Me.PictureBox16)
        Me.Controls.Add(Me.PictureBox15)
        Me.Controls.Add(Me.PictureBox14)
        Me.Controls.Add(Me.PictureBox13)
        Me.Controls.Add(Me.PictureBox12)
        Me.Controls.Add(Me.PictureBox11)
        Me.Controls.Add(Me.PictureBox10)
        Me.Controls.Add(Me.PictureBox9)
        Me.Controls.Add(Me.PictureBox8)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Form1"
        Me.Text = "Visualisasi Automated Toll Payment"
        Me.grpMOBIL.ResumeLayout(False)
        Me.grpMOBIL.PerformLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox67, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox66, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctLAMPUETOLL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox65, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox61, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox121, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox58, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox56, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox89, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox64, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctLORONG2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctLORONG1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.palang, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox84, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LAMPUAPT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox63, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox151, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox59, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox116, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox62, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctPALANGETOLL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox117, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox55, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox60, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctETOLL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox150, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox148, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox68, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox70, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox87, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox139, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox140, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox141, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctMOBILAPT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox138, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox137, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox135, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox136, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox134, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox133, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox132, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox131, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox130, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox129, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox128, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox127, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox125, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox124, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox123, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox120, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox119, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox118, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox90, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox91, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox92, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox93, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox94, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox95, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox96, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox97, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox98, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox99, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox100, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox101, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox102, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox103, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox104, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox105, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox106, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox107, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox108, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox109, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox110, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox111, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox112, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox113, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox114, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox115, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox88, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox86, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox85, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox79, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox57, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox77, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox76, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox74, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox73, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox72, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox71, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox69, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctMLAMA, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctMBIASA, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctSPORT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pctMOBILPOL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox75, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox54, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox53, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox52, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox51, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox50, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox49, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox48, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox47, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox46, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox45, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox44, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox43, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox42, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox41, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox40, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox39, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox38, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox37, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox36, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox35, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox30, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox12 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox13 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox14 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox15 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox16 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox17 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox18 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox19 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox20 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox21 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox22 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox23 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox24 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox25 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox26 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox27 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox28 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox29 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox30 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox31 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox32 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox33 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox34 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox35 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox36 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox37 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox38 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox39 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox40 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox41 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox42 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox43 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox44 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox45 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox46 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox47 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox48 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox49 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox50 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox51 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox52 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox53 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox54 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox75 As System.Windows.Forms.PictureBox
    Friend WithEvents pctMOBILPOL As System.Windows.Forms.PictureBox
    Friend WithEvents tmrmobilcepat As System.Windows.Forms.Timer
    Friend WithEvents pctSPORT As System.Windows.Forms.PictureBox
    Friend WithEvents pctMBIASA As System.Windows.Forms.PictureBox
    Friend WithEvents pctMLAMA As System.Windows.Forms.PictureBox
    Friend WithEvents tmrmobilbiasa As System.Windows.Forms.Timer
    Friend WithEvents tmrmobillama As System.Windows.Forms.Timer
    Friend WithEvents tmrpolisi As System.Windows.Forms.Timer
    Friend WithEvents PictureBox56 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox55 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox57 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox62 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox63 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox65 As System.Windows.Forms.PictureBox
    Friend WithEvents LAMPUAPT As System.Windows.Forms.PictureBox
    Friend WithEvents pctLAMPUETOLL As System.Windows.Forms.PictureBox
    Friend WithEvents palang As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox69 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox71 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox72 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox73 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox74 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox76 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox77 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox79 As System.Windows.Forms.PictureBox
    Friend WithEvents pctPALANGETOLL As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox84 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox85 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox86 As System.Windows.Forms.PictureBox
    Friend WithEvents pctMOBILAPT As System.Windows.Forms.PictureBox
    Friend WithEvents tmrMOBILAPT As System.Windows.Forms.Timer
    Friend WithEvents tmrPALANG As System.Windows.Forms.Timer
    Friend WithEvents PictureBox58 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox88 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox89 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox103 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox104 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox105 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox106 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox107 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox108 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox109 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox110 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox111 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox112 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox113 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox114 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox115 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox90 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox91 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox92 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox93 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox94 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox95 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox96 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox97 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox98 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox99 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox100 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox101 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox102 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox116 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox59 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox117 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox118 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox119 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox120 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox60 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox121 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox61 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox123 As System.Windows.Forms.PictureBox
    Friend WithEvents TmrCHECKDB As System.Windows.Forms.Timer
    Friend WithEvents tmrMOBILAPT2 As System.Windows.Forms.Timer
    Friend WithEvents tmrPALANG2 As System.Windows.Forms.Timer
    Friend WithEvents tmrETOLL As System.Windows.Forms.Timer
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents PictureBox124 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox125 As System.Windows.Forms.PictureBox
    Friend WithEvents txtSTATUS As System.Windows.Forms.TextBox
    Friend WithEvents lblgate As System.Windows.Forms.Label
    Friend WithEvents PictureBox127 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox128 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox129 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox130 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox131 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox132 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox133 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox134 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox135 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox136 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox137 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox138 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox68 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox70 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox87 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox139 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox140 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox141 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox148 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox150 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox151 As System.Windows.Forms.PictureBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents pctLORONG1 As System.Windows.Forms.PictureBox
    Friend WithEvents pctLORONG2 As System.Windows.Forms.PictureBox
    Friend WithEvents btnHIDE As System.Windows.Forms.Button
    Friend WithEvents PictureBox64 As System.Windows.Forms.PictureBox
    Friend WithEvents pctETOLL As System.Windows.Forms.PictureBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents labelgate As System.Windows.Forms.Label
    Friend WithEvents lblETOLL As System.Windows.Forms.Label
    Friend WithEvents tmrWKTETOLL As System.Windows.Forms.Timer
    Friend WithEvents PictureBox66 As System.Windows.Forms.PictureBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents tmrPALANGETOLL As System.Windows.Forms.Timer
    Friend WithEvents tmrPALANGETOLL2 As System.Windows.Forms.Timer
    Friend WithEvents PictureBox67 As System.Windows.Forms.PictureBox
    Friend WithEvents txtPENGEMUDI As System.Windows.Forms.TextBox
    Friend WithEvents lbltopay As System.Windows.Forms.Label
    Friend WithEvents lblpulsa As System.Windows.Forms.Label
    Friend WithEvents lblharga As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents grpMOBIL As System.Windows.Forms.GroupBox
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents tmrETOLL2 As System.Windows.Forms.Timer
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer

End Class
